import Vue from 'vue'
import Router from 'vue-router'
import Hello from '@/components/Hello'
import Chapter from '@/components/Chapter'
import UserCenter from '@/components/Home/UserCenter'
import Search from '@/components/Search'
import Navigator from '@/components/Home/Navigator'
import Register from '@/components/Home/Register'
import SetInfo from '@/components/Home/SetInfo'
import Login from '@/components/Home/Login'
import MsgLogin from '@/components/Home/MsgLogin'
import UpdateInfo from '@/components/Home/UpdateInfo'
import vSet from '@/components/Home/Set'

//按需加载组件方法
// const Chapter = r => require.ensure([], () => r(require('@/components/Chapter')), 'group-foo')
Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Hello',
      component: Hello
    },
    {
      path: '/Chapter/:id',
      name: 'Chapter',
      component: Chapter
    },
    {
      path: '/UserCenter',
      name: 'UserCenter',
      component: UserCenter
    },
    {
      path: '/Search',
      name: 'Search',
      component: Search
    },
 	{
 		path: '/Navigator',
 		name: 'Navigator',
 		component: Navigator
 	},
 	{
 		path: '/Register',
 		name: 'Register',
 		component: Register
 	},
  {
    path: '/SetInfo',
    name: 'SetInfo',
    component: SetInfo
  },
  {
    path: '/Login',
    name: 'Login',
    component: Login
  },
  {
    path: '/MsgLogin',
    name: 'MsgLogin',
    component: MsgLogin
  },
  {
    path: '/UpdateInfo',
    name: 'UpdateInfo',
    component: UpdateInfo
  },
  {
    path: '/Set',
    name: 'Set',
    component: vSet
  }                   
  ]
})
